﻿using System;
namespace Arrays;

class Program
{
    static void Main(string[] args)
    {
        /*
        //Arrays in C#
        //Declaration of arrays
        //datatype [] arrayName = new dataype[SIZE];
        //const int SIZE = 10;
        //int[] myArray = new int[5] { 1,2,3,4,5};//most suitable method
        //c++ int array[5] = {1,2,3,4,5};
        //int[] arrayy = { 1, 2, 3, 4, 5, 6, 7 };
        //string[] stringArray = new string[] { "one", "two", "three" };
        //const int SIZE = 5;
        double[] mydouble = new double[5];
        /*mydouble[0] = 10;
        mydouble[1] = 20;
        mydouble[2] = 30;
        mydouble[3] = 40;
        mydouble[4] = 50;
        Console.WriteLine(mydouble[0]);
        Console.WriteLine(mydouble[1]);
        Console.WriteLine(mydouble[2]);
        Console.WriteLine(mydouble[3]);
        Console.WriteLine(mydouble[4]);*/
        /*
        for(int i=0;i<mydouble.Length ; i++)
        {
            Console.Write("Enter array:{0}:\t",i);
            mydouble[i] = double.Parse(Console.ReadLine());
        }
        Console.WriteLine("\n-------Displaying of arrays--------\n");
        //for(int i=0;i< mydouble.Length; i++)
        //{
        //    Console.WriteLine(mydouble[i]);
        //}
        foreach (double i in mydouble)
        {
            Console.WriteLine(i);
        }
        //Console.WriteLine(mydouble.Max());*/




        //two types of Arrays
        //Rectangular Arrays
        //2 D Arrays
        //declaration of 2 D Arrays
        //int[,] my2dArray = new int[3, 3] { { 1, 2, 3 },{ 4, 5, 6 },{ 7,8,9} };
        //c++--->int aray[ROWS][COLS]
        //C#---->int [,] myaray = new int[rows,cols]
        int[,] my2dArray = new int[3,3];
        Console.WriteLine("\n------Get input from user---------\n");
        for(int i=0;i<3;i++)
        {
            for(int j=0;j<3;j++)
            {
                Console.Write("Enter array:[{0},{1}]",i,j);
                my2dArray[i, j] = int.Parse(Console.ReadLine());
            }
        }

        Console.WriteLine("\n--------Displaying of Array------\n");
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                Console.Write("{0} ",my2dArray[ i , j ]);
            }
            Console.WriteLine();
        }

        //Jagged Arrays

    }
}

