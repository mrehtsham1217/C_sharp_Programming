﻿using System;
namespace Class_objcet_oop;
class Program
{
    static void Main(string[] args)
    {
        //Creation of object
        Student obj1 = new Student();
        Student obj2 = new Student();
        Student obj3 = new Student("Ali",01,"BSSE");//-->parameterize
        obj1.Printdata();
        obj2.Printdata();
        obj3.Printdata();
        
;    }
}

