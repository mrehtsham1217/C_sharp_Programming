﻿using System;
namespace This_keyword_constructor_overloading
{
	public class Employee
	{
		//This-->keyword
		private string Ename;
		private string designation;
		private string factoryName;
		private int age;
		//parameterize constructor
		public Employee(string Ename,string designation, string factoryName,int age)
		{
			//this keyword refers to current object
			this.Ename = Ename;
			this.designation = designation;
			this.factoryName = factoryName;
			this.age = age;

		}
		public void displayData()
		{
			Console.WriteLine("Employee Name:\t\t{0}",Ename);
            Console.WriteLine("Employee's Desgination:\t{0}", designation);
            Console.WriteLine("Employee's Factory:\t\t{0}", factoryName);
            Console.WriteLine("Employee's Age:\t\t\t{0}", age);
			Console.WriteLine("\n------------------------------------\n");

        }
		//Constructor overloading
		// function or method overlaoding-->differnt function with same namee
		public Employee(string Ename)
		{
			this.Ename = Ename;

		}

		//public Employee(string designation)
		//{
		//	this.designation = designation;
		//}
		//public Employee(string factoryName)
		//{
		//	this.factoryName = factoryName;
		//}
		public Employee(int age)
		{
			this.age = age;
		}
    }
}

