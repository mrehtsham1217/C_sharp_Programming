﻿using System;
namespace call_by_value_ref_out;

class Program
{
    //Methods-->3 types
    //no return type-->no paramters
    public static void swapp(int number1,int number2)
    {
        //Call by value-->copy-->changes occur in copy
        int temp = number1;
        number1 = number2;
        number2 = temp;
        Console.WriteLine("Values in function:{0},{1}",number1,number2);
    }
    //call by reference in C#
    public static void swappp(ref int number1, ref int number2)
    {
        //Call by value-->copy-->changes occur in copy
        int temp = number1;
        number1 = number2;
        number2 = temp;
        Console.WriteLine("Values in function:{0},{1}", number1, number2);
    }
    public static int sum(int num1,int num2, out int answer)
    {
        //--01-->if we dont want to give values in function
        //02--If we dont want to pass values in main function
        answer = num1 + num2;
        return answer;

    }
    public static void city(out string one,out string two,out string three)
    {
        one = "Lahore";
        two = "Islamabad";
        three = "Karachi";
        Console.WriteLine("{0},{1},{2}",one,two,three);
    }

    //no return type-->with parameters
    //with return type and with parameters
    //int main()---->C++
    static void Main(string[] args)
    {
        //Methods in C#-->functions
        //Methods-->call by value-->Call by reference-->out keyword-->param keyword-->arrays to functions
        //Why we use functions
        //Divide and solve-->combine
        //Reuseability-->
        //Software--->divide and conquere-->integrate--->solve-->combine
        //Welcome-->welcome code --->function-->call again and again
        int num1 = 30;
        int num2 = 40;
        /*Console.WriteLine("Before swaping:{0},{1}",num1,num2);
        swapp(num1, num2);
        Console.WriteLine("After swaping:{0},{1}",num1,num2);*/
        //Console.WriteLine("Before swaping:{0},{1}", num1, num2);
        //swappp(ref num1, ref num2);//calling of function
        //Console.WriteLine("After swaping:{0},{1}", num1, num2);
        Console.WriteLine(sum(num1,num2,out int answer));
        city(out string one, out string two, out string three);


    }
}

