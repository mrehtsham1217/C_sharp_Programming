﻿using System;
namespace Class_objcet_oop
{
	public class Student
	{
		//Constructor in OOPS
		/*
		 01-->Special method-->Class Name
		02-->Class power
		//Object create help--->
		 */
		//Types
		/*
		 04--Types
		-01--->default constructor
		02--Parameterize constructor
		03->Copy Constructor
		04-->Static COnstructor
		 */
		//Access modifier-->public-->private-->private:
		private string name;
		private int regNO;
		private string department;
		//Default constructor
		public Student()
		{
			//default constructor
			name = "Ali";
			regNO = 10;
			department = "BSCS";
		}
		//Parameterize constructor
		public Student(string Name,int RegNO,string Deparrtment)
		{
			//left side data is private data-->Abstract data
			name = Name;
			regNO = RegNO;
			department = Deparrtment;
		}
		//ctor-->Double tab--?cntrl k + c--->cntrl k + u
		//Data printing methods
		public void Printdata()
		{
			Console.WriteLine("Name:{0}",name);
			Console.WriteLine("RegNO:{0}",regNO);
			Console.WriteLine("Department:{0}",department);
			Console.WriteLine("\n-----------------------------\n");
		}
	}
}

