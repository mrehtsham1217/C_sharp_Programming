﻿namespace Constructor_chaining;

class Program
{
    static void Main(string[] args)
    {
        Student std1 = new Student("ALi", 5.5);
        Student std2 = new Student("Abdullah");
        Student std3 = new Student(4.9);
        std1.Display();
        std2.Display();
        std3.Display();
    }
}

