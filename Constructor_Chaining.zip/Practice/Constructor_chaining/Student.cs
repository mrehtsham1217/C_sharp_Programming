﻿using System;
namespace Constructor_chaining
{
	public class Student
	{
		private string SName;
		private double cgpa;
		//constructor chaining--->Constructor overlaoding
		//method--->appraoches-->4
		public Student(string SName=" ",double cgpa = 0.0)
		{
			this.SName = SName;
            //3rd approach---this keyword
            if (cgpa > 4 || cgpa < 0)
            {
                Console.WriteLine("Your CGPA is invalid");
                this.cgpa = 0;
            }
            else
                this.cgpa = cgpa;
            //2nd approach
            //checkCGPa(cgpa);
            //----------->>ist--appraoch
            //if (cgpa > 4 || cgpa < 0)
            //{
            //    Console.WriteLine("Your CGPA is invalid");
            //    this.cgpa = 0;
            //}
            //else
            //    this.cgpa = cgpa;

        }
		//2nd construcor for cgpa
		public Student(double cgpa)//:this(" ",0)
		{
			//checkCGPa(cgpa);
			//------->>first appraoch
			//if(cgpa > 4 || cgpa <0)
			//{
			//	Console.WriteLine("Your CGPA is invalid");
			//	this.cgpa = 0;
			//}
			//else
			//this.cgpa = cgpa;


		}
		//third for name
		public Student(string SName)//:this(SName,0)
		{
			this.SName = SName;
		}
		public void Display()
		{
			Console.WriteLine("NAme:\t{0}",SName);
			Console.WriteLine("Cgpa:\t{0}",cgpa);
			Console.WriteLine("\n---------------------\n");
		}
		public void checkCGPa(double cgpa)
		{
            if (cgpa > 4 || cgpa < 0)
            {
                Console.WriteLine("Your CGPA is invalid");
                this.cgpa = 0;
            }
            else
                this.cgpa = cgpa;
        }
	}
}

