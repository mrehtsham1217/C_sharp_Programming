﻿using System;
namespace Methods_Overloading;

class Program
{
    public static int Add(int num1,int num2)
    {
        return num1 + num2;
    }
    public static double Add(double num1,double num2)
    {
        return num1 + num2;
    }
    public static long Add(long num1, long num2)
    {
        return num1 + num2;
    }
    static void Main(string[] args)
    {
        //function overloading
        //if a function has same name-->but different in rerturn type and parameters
        Console.WriteLine(Add(50000,600000));//with parameters we came to know that which function is calling
        Console.WriteLine(Add(5.555,6.666));
        Console.WriteLine(Add(10,20));
    }
}

