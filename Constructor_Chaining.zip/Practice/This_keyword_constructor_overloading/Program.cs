﻿using System;
namespace This_keyword_constructor_overloading;

class Program
{
    static void Main(string[] args)
    {
        //Creation of object
        //ClassName ObjectName = new ClassName(parameters);
        Employee emp = new Employee("ALi","MAnager","MTM",35);
        Employee emp2 = new Employee(40);
        Employee emp3 = new Employee("Abdullah");
        emp.displayData();
        emp2.displayData();
        emp3.displayData();
    }
}

