﻿using System;
namespace while_do_while_loops;

class Program
{
    static void Main(string[] args)
    {
        //Console.WriteLine("Hello, World!");
        //while and do while loop
        //why we use loops-->
        //conditions-->
        //starting point--->100,1,15
        //ending pointing-->100-->ending
        //jump-->1+1+2+3+4

        //--->Starting point of loop-->
        /*int i = 0;//-->starting point
        while (i<=10)//ending point
        {
            //Console.WriteLine("hello world");
            Console.WriteLine(i);
            i = i + 2;
        }*/
        /*
        5 x 1  = 5
        5 x 2 = 10
        5 X 3 = 15
         */
        /*int table,limit;
        Console.WriteLine("Enter table:\t");
        table = int.Parse(Console.ReadLine());
        Console.WriteLine("Enter the limit of table:\t");
        limit = int.Parse(Console.ReadLine());
        int i = 1;//--->starting point
        while (i <= limit)
        {
            Console.WriteLine("{0} X {1} = {2}",table,i,table*i);
            i++;//jump of loop
        }*/
        int i = 1;
        int table,limit;
        Console.WriteLine("Enter table:\t");
        table = int.Parse(Console.ReadLine());
        Console.WriteLine("Enter limit for table:\t");
        limit = int.Parse(Console.ReadLine());
        do
        {
            //Console.WriteLine(i);
            Console.WriteLine("{0} X {1} = {2}", table, i, table * i);        i++;
        }while (i<=limit);//ending limit-->must be provided in while body
    }
}

