﻿using System;
namespace Methods;

class Program
{
    /*
     01->no return type--->no parameteres
    02-->no return type--->with paramters
    03-->return type ---->with parameters
     */
    public static void Helloword()
    {
        Console.WriteLine("Welcome to methods in C#");
    }
    public static void Square(int num1)
    {
        Console.WriteLine("The square of number is {0}:\t",num1*num1);
    }
    public static int cube(int num1)
    {
        return num1 * num1 * num1;
    }
    static void Main(string[] args)
    {
        //Console.WriteLine("Hello, World!");
        //calling of function
        Helloword();
        Helloword();
        int numm1 = 20;
        Square(numm1);
        int result = cube(numm1);
        Console.WriteLine("The cube of function is :{0}\t",result);

        //Methods in C#
        //website-->navbar-->slider->body->footer-->methods
        //work-->3,4,5--->combine-->
        //divide-->reuseable-->easy to handle
        //How to create methods or functions in C#

    }
}

