﻿using System;
namespace call_by_value_ref_out;

class Program
{
    //How to pass a function--->call by value--->call by reference-->out keyword-->param keyword-->Arrays
    //--01-->Call  by value
    public static void Swapp(int number1,int number2)
    {
        //call by value-->has no effect on orignal values
        int temp = number1;
        number1 = number2;
        number2 = temp;
        Console.WriteLine("The value in fuhnction:\n {0}-->{1}",number1,number2);
    }
    //call by reference--->
    public static void Swappp(ref int number1, ref int number2)
    {
        //call by value-->has no effect on orignal values
        int temp = number1;
        number1 = number2;
        number2 = temp;
        Console.WriteLine("The value in fuhnction:\n {0}-->{1}", number1, number2);
    }
    //--->Out keyword--->
    public static void sum(int num1,int num2,out int answer)
    {
        answer = num1 + num2;
        Console.WriteLine("The sum of 2 numbers is:\t {0}",answer);
    }
    public static void dataOutput(out string one,out string two,out string three)
    {
        one = "LAhore";
        two = "Karachi";
        three = "Fsd";
        Console.WriteLine("{0}\n{1}\n{2}",one,two,three);
    }

    static void Main(string[] args)
    {
        /*int num1 = 50;
        int num2 = 100;
        Console.WriteLine("\n---Before swaping:\n{0}-->{1}", num1, num2);
        Swapp(num1, num2);
        Console.WriteLine("\n---After swaping:\n{0}-->{1}", num1, num2);*/
        // Console.WriteLine("Hello, World!");
        /*int num1 = 50;
        int num2 = 100;
        Console.WriteLine("\n---Before swaping:\n{0}-->{1}",num1,num2);
        Swappp(ref num1, ref num2);
        Console.WriteLine("\n---After swaping:\n{0}-->{1}", num1, num2);*/
        /*
         num1 = 10
        num2 = 20;
        //---------------->
         num1  = 20
        num2  = 10;
         */
        //----------------Out keyword in methods---------->
        int answer;
        string one, two, three;
        sum(10, 20, out answer);
        dataOutput(out one, out two, out three);

    }
}

