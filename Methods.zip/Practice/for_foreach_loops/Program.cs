﻿using System;
namespace for_foreach_loops;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
        //for loop and foreach loop
        //loop-->starting point--->ending point-->jump

        /* for(int i = 0;i<10;i++)//0<=10-->1<=10-->
         {
             //Console.WriteLine("{0} X {1} = {2}",5,i,5*i);
         }*/
        //nested for loop
        /*for(int i = 0;i<10;i++)//i=1-->0<=1--j=1 i<=1
         {//nested for loop must be used for 2D works
             for(int j=10;j>=i;j--)
             {
                 Console.Write("#");
             }
             Console.WriteLine();
         }*/
        //Break and continue statement
        //for(int i=0;i<10;i++)
        // {
        //     if (i == 5)
        //         continue;
        //     Console.WriteLine(i);
        // }
        string[] array = { "ali", "reham", "faran", "Ahsan" };
        foreach(string i in array)
        {
            Console.WriteLine(i);
        }
    }
}

