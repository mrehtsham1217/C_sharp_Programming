﻿namespace typecasting;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
        //There are two type of typecasting
        //--01--Implicit-->small to larger-->char->int->float->long->double
        //02 --Explicit type-->double-long->float->int-->char
        /*char ch = 'A';
        int myInt = (int)ch;
        Console.WriteLine(myInt);*/
        //int myInt = 65;
        //Console.WriteLine(myInt.GetType());
        //Type datatype = myInt.GetType();
        //Console.WriteLine(datatype);
        /*float myFloat = (float)myInt;
        Console.WriteLine(myFloat.GetType());*/

        //-----------Explicit typecasting---------
        /*double mydouble = 9.55;
        int myint = (int)mydouble;
        Console.WriteLine(myint);
        Console.WriteLine(mydouble);*/

        /*double mydouble = 9.35;
        Console.WriteLine(Convert.ToString(mydouble));
        //Convert.Todoubl*/

        //How to take input from user
        //string name;
        //Console.WriteLine("Enter your name:\t");
        //name = Console.ReadLine();
        //cin>>name
        //Console.WriteLine("Your name is:\t{0}",name); number
        double number;//by default in string
        Console.WriteLine("Enter a number:\t");
        //number = Convert.ToDouble(Console.ReadLine());
        number = double.Parse(Console.ReadLine());

        Console.WriteLine("Your number is:\t{0}",number);
    }
}
