﻿using System;
namespace params_keyword;

class Program
{
    public static int sum(params int[] array)
    {
        int sum = 0;
        for(int i=0;i<array.Length;i++)
        {
            sum = sum + array[i];//0+1=1+2 = 3
        }
        return sum/array.Length;
    }
    public static void inputArray(params int[] array)
    {
        for(int i=0;i<array.Length;i++)
        {
            Console.Write("Enter array [{0}]",i);
            array[i] = int.Parse(Console.ReadLine());
        }
    }
    public static void outputArray(params int[]array)
    {
        for(int i=0;i<array.Length;i++)
        {
            Console.WriteLine(array[i]);
        }
    }
    public static int maxx(params int[]array)
    {
        int max = 0;
        for(int i=0;i<array.Length;i++)
        {
            if (array[i] > max)
                max = array[i];
        }
        return max;
    }
    public static void inputArrayfun(int[,]array)
    {
        for(int i=0;i<4;i++)
        {
            for(int j=0;j<4;j++)
            {
                Console.Write("Enter array [{0},{1}]",i,j);
                array[i, j] = int.Parse(Console.ReadLine());
            }
        }
    }
    public static void outputArrayfun(int[,] array)
    {
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                Console.Write("{0}\t" ,array[i, j]);
            }
            Console.WriteLine();
        }
    }

    static void Main(string[] args)
    {
        //use of params keyoword and how to pass arrays in functions in C#
        //call by references
        //int[] myArray = new int[] { 1, 2, 3, 4, 5, 6, 7, 8 };
        //Console.WriteLine(sum(myArray));
        /*int[] myArray = new int[5];
        inputArray(myArray);
        outputArray(myArray);
        Console.WriteLine("Tha max values is {0}",maxx(myArray));*/
        int[,] array = new int[4, 4];
        inputArrayfun(array);
        outputArrayfun(array);

    }
}

