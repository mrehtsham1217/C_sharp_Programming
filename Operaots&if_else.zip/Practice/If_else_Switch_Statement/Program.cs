﻿using System;
namespace If_else_Switch_Statement;

class Program
{
    static void Main(string[] args)
    {
        //If else and switch statement
        //Conditional sentences
        /*int number1 = 20;
        int number2 = 20;
        if(number1 > number2)
        {
            Console.WriteLine("Number1 is greater than number 2");
        }
        else if(number1==number2)
        {
            Console.WriteLine("Both are equal");
        }
        else
        {
            Console.WriteLine("Number2 is greater than number1");
        }*/
        /*double height;
        double weight;
        Console.WriteLine("Enter your height in meters:\t");
        height = double.Parse(Console.ReadLine());
        Console.WriteLine("Enter your weight in (kg):\t");
        weight = double.Parse(Console.ReadLine());
        double BMI = weight/(height*height);
        //if BMI 20--->fit-->BMI < 18 weak-->25 > fatty
        if(BMI <18)
        {
            Console.WriteLine("you need to gain some weight:\n");
        }
        else if(BMI > 18 && BMI < 25)
        {
            Console.WriteLine("you are perfect and fine:\n");
        }
        else if(BMI > 25 && BMI <30)
        {
            Console.WriteLine(" You are over weight:\n");
        }
        else
        {
            Console.WriteLine("You are fatty:\n");
        }*/
        //ternary opetrator
        /*int number1 = 20;
        int number2 = 30;
        //short hand if else
        string result = (number1 > number2) ? "Number1 is greater" : "Number2 is greater";
        Console.WriteLine(result);*/
        //Switch statement
        /*char ch;
        Console.WriteLine("Enter any character:\t");
        ch = char.Parse(Console.ReadLine());
        switch (ch)
        {
            case 'A':
            case 'a':
                Console.WriteLine("A or a both are vowels:\n");
                break;
            case 'E':
            case 'e':
                Console.WriteLine("E or e both are vowels:\n");
                break;
            case 'I':
            case 'i':
                Console.WriteLine("I or i both are vowels:\n");
                break;
            case 'O':
            case 'o':
                Console.WriteLine("O or o both are vowels:\n");
                break;
            case 'U':
            case 'u':
                Console.WriteLine("U or u both are vowels:\n");
                break;
            default:
                Console.WriteLine("Consonants:\n");
                break;
        }*/

        int marks;
        Console.WriteLine(  "Enter your marks:\t");
        marks = int.Parse(Console.ReadLine());
        switch (marks/10)//--90-->90/10-->9
        {
            case 9:
                Console.WriteLine("A grade");
                break;
            case 8:
                Console.WriteLine("B grade");
                break;
            case 7:
                Console.WriteLine("C grade");
                break;
            case 6:
                Console.WriteLine("D grade");
                break;
            default:
                Console.WriteLine("F grade");
                break;
        }

    }
}

