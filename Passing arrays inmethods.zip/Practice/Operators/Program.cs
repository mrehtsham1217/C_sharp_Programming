﻿using System;
namespace Operators;

class Program
{
    static void Main(string[] args)
    {
        /*
        //Operators in C#
        //-01 Arithmatic operators-->+,-,*,/,++,--,%
        int number = 10;
        int number2 = 20;
        Console.WriteLine(number2 % number);
        number++;
        number2--;
        Console.WriteLine(number);
        Console.WriteLine(number2);
        //02 --Comparsion operator >,<,>=,<=
        int number3 = 20;
        int number4 = 20;
        Console.WriteLine(number3 <= number4);
        //--03--Logical operator--&&,||,
        //and between two conditions
        Console.WriteLine("\n------Logical operator-------\n");
        Console.WriteLine(!(number3 >10 || number4 < 15));
        //04--Assignemnt operators,=,>=
        int variable = 30; */
        Console.WriteLine(Math.Min(29,40));
        Console.WriteLine(Math.Sqrt(65));
        Console.WriteLine(Math.Round(6.9997));
        Console.WriteLine(Math.Abs(-4.77));
        Console.WriteLine(Math.PI);
        const float PI = 3.14F;
        
    }
}

