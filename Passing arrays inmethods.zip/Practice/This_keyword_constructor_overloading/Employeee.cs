﻿using System;
namespace This_keyword_constructor_overloading
{
	public class Employeee
	{
		private string EName;
		private string designation;
		private int age;
		private string factorName;
		//this-->Current object refer--->
		 public Employeee(string EName,string designation,int age,string factorName)
		{
			this.EName = EName;
			this.designation = designation;
			this.age = age;
			this.factorName = factorName;
		}
		
		//Constructor overloading
		public Employeee(string EName)
		{
			this.EName = EName;
		}
		//public Employeee(string designation)
		//{
		//	this.designation = designation;
		//}
		public Employeee(int age)
		{
			this.age = age;
		}
		//public Employeee(string factorName)
		//{
		//	this.factorName = factorName;
		//}
		public void printData()
		{
			Console.WriteLine("EMployee Name:\t\t{0}",EName);
            Console.WriteLine("EMployee Designation:\t{0}", designation);
            Console.WriteLine("EMployee age:\t\t{0}", age);
            Console.WriteLine("EMployee's Factor:\t{0}", factorName);
			Console.WriteLine("\n----------------------------------\n");

        }
    }
}

