﻿using System;
namespace This_keyword_constructor_overloading;

class Program
{
    static void Main(string[] args)
    {
        //Creation of an object
        Employeee emp = new Employeee("Ali","Manager",35,"MTM");
        emp.printData();
        Employeee emp2 = new Employeee("Hassan");
        emp2.printData();
        Employeee emp3 = new Employeee(35);
        emp3.printData();
    }
}

