﻿using System;
namespace jagged_Arrays;
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
        //Jagged Arrays
        /* int[][] jagged = { new int []{1,2,3,4,5},
             new int[]{6,7},
             new int[]{8,9,10,11}

         };*/
        int[][] jagged = new int[3][];
        jagged[0] = new int[5];//first row contain 5 columns
        jagged[1] = new int[3];//2nd row contain 3 cols
        jagged[2] = new int[4];//3rd row contain 4 cols
        Console.WriteLine("\n-----Getting input from user of jagged arrays------\n");
        for (int i = 0; i < 5; i++)
        {
            Console.Write("Enter array:[{0}]",i);
            jagged[0][i] = int.Parse(Console.ReadLine());
        }
        for (int j = 0; j < 3; j++)
        {
            Console.Write("Enter array:[{0}]", j);
            jagged[1][j] = int.Parse(Console.ReadLine());
        }
        for (int k = 0; k < 4; k++)
        {
            Console.Write("Enter array:[{0}]", k);
            jagged[2][k] = int.Parse(Console.ReadLine());
        }


        Console.WriteLine("\n------Displaying of JAgged Array--------\n");
        for(int i=0;i<5;i++)
            Console.Write(jagged[0][i] + "\t");
        Console.WriteLine();
        for(int j=0;j<3;j++)
            Console.Write(jagged[1][j]+"\t");
        Console.WriteLine();
        for(int k=0;k<4;k++)
            Console.Write(jagged[2][k]+"\t");

    }
}

