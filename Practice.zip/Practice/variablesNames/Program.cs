﻿using System;
namespace variablesNames;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
        //Comments in c#
        //functions for output
        /*
         welcome to c#
        programming language
         */
        //VAriables in C#
        int number = 10;
        float floatNumber = 20.5F;
        double doubleNumber = 20.55d;
        Console.WriteLine(number);
        Console.WriteLine(floatNumber);
        Console.WriteLine(doubleNumber);
        string name = "Ali";
        //char ch = 'A';
        int age = 20; 
        Console.WriteLine("youe name is " + name);
        Console.WriteLine("Your name is {0}:\t{1}:\t",name,age);
        Console.WriteLine(5<9);
        //How to declare a good variable name
        //string n;
        //string Firstname;
        //PascalCase--->FirstNameOf;
        //camelCase--->firstNameOf
        //snake_case first_name
        //multiple variables
        int x, y, z;
        x = 30; y = 40; z = 50;
        Console.WriteLine(x+y+z);

        
    }
}

