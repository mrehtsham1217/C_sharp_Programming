﻿using System;
namespace variablesNames;

class Program
{
    static void Main(string[] args)
    {
        /*Console.WriteLine("Hello, World!");
        //Comments in c#
        //functions for output
        /*
         welcome to c#
        programming language
         */
        //VAriables in C#
        /*int number = 10;
        float floatNumber = 20.5F;
        double doubleNumber = 20.55d;
        Console.WriteLine(number);
        Console.WriteLine(floatNumber);
        Console.WriteLine(doubleNumber);
        string name = "Ali";
        //char ch = 'A';
        int age = 20; 
        Console.WriteLine("youe name is " + name);
        Console.WriteLine("Your name is {0}:\t{1}:\t",name,age);
        Console.WriteLine(5<9);
        //How to declare a good variable name
        //string n;
        //string Firstname;
        //PascalCase--->FirstNameOf;
        //camelCase--->firstNameOf
        //snake_case first_name
        //multiple variables
        int x, y, z;
        x = 30; y = 40; z = 50;
        Console.WriteLine(x+y+z);*/


        double mydouble = 9.555;
        int myInt = (int)mydouble;
        Console.WriteLine(mydouble);
        Console.WriteLine(myInt);
        float myFLoat = (float)mydouble;
        char ch = 'A';
        int number = (int)ch;
        Console.WriteLine(number);
        int number2 = 65;
        char number2Change = (char)number2;
        Console.WriteLine(number2Change);
        float number3 = (float)number2;
        Console.WriteLine(number3);
        Console.WriteLine(number3.GetType());
        Type dataType = number.GetType();
        Console.WriteLine(dataType);
        Console.WriteLine("\n----------------------\n");
        int a = 66;
        double b = 30.05;
        bool myBool = true;
        Console.WriteLine(Convert.ToSingle(a));
        Console.WriteLine(Convert.ToInt32(b));
        Console.WriteLine(Convert.ToString(myBool));


    }
}

